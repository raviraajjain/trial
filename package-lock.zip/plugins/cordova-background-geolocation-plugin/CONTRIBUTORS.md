# Contributors

Many thanks to all contributors and special thanks to [christocracy](https://github.com/christocracy) and [mauron85](https://github.com/mauron85) as former authors.

* [mauron85](https://github.com/mauron85)
* [christocracy](https://github.com/christocracy)
* [huttj](https://github.com/huttj)
* [erikkemperman](https://github.com/erikkemperman)
* [codebling](https://github.com/codebling)
* [pmwisdom](https://github.com/pmwisdom)
* [nevyn](https://github.com/nevyn)
* [unixmonkey](https://github.com/unixmonkey)
* [Arakaki-Yuji](https://github.com/Arakaki-Yuji)
* [HarelM](https://github.com/HarelM)
* [RaddishIoW](https://github.com/RaddishIoW)
