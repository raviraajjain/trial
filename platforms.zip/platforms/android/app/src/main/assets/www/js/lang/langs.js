var available_langs = [
    {country:'gb',code:'en',name:'English',dir:'ltr'},
    {country:'in',code:'hi',name:'Hindi (हिंदी)',dir:'ltr'},
    {country:'es',code:'es',name:'Spanish (Español)',dir:'ltr'},
    {country:'fr',code:'fr',name:'French (français)',dir:'ltr'},
    {country:'de',code:'de',name:'Deutsch',dir:'ltr'},
    {country:'sa',code:'ar',name:'Arabic (عربي)',dir:'rtl'},
    {country:'ru',code:'ru',name:'Russian (русский)',dir:'ltr'},
    {country:'pt',code:'pt',name:'Portuguese (português)',dir:'ltr'}
];