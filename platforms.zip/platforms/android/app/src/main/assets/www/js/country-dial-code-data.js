var country_dial_code_data = {
    "us": {
        "country": "United States",
        "dial_code": 1,
        "country_code": "us"
    },
    "gb": {
        "country": "United Kingdom",
        "dial_code": 44,
        "country_code": "gb"
    },
    "af": {
        "country": "Afghanistan (‫افغانستان‬‎)",
        "dial_code": 93,
        "country_code": "af"
    },
    "al": {
        "country": "Albania (Shqipëri)",
        "dial_code": 355,
        "country_code": "al"
    },
    "dz": {
        "country": "Algeria (‫الجزائر‬‎)",
        "dial_code": 213,
        "country_code": "dz"
    },
    "as": {
        "country": "American Samoa",
        "dial_code": 1,
        "country_code": "as"
    },
    "ad": {
        "country": "Andorra",
        "dial_code": 376,
        "country_code": "ad"
    },
    "ao": {
        "country": "Angola",
        "dial_code": 244,
        "country_code": "ao"
    },
    "ai": {
        "country": "Anguilla",
        "dial_code": 1,
        "country_code": "ai"
    },
    "ag": {
        "country": "Antigua and Barbuda",
        "dial_code": 1,
        "country_code": "ag"
    },
    "ar": {
        "country": "Argentina",
        "dial_code": 54,
        "country_code": "ar"
    },
    "am": {
        "country": "Armenia (Հայաստան)",
        "dial_code": 374,
        "country_code": "am"
    },
    "aw": {
        "country": "Aruba",
        "dial_code": 297,
        "country_code": "aw"
    },
    "au": {
        "country": "Australia",
        "dial_code": 61,
        "country_code": "au"
    },
    "at": {
        "country": "Austria (Österreich)",
        "dial_code": 43,
        "country_code": "at"
    },
    "az": {
        "country": "Azerbaijan (Azərbaycan)",
        "dial_code": 994,
        "country_code": "az"
    },
    "bs": {
        "country": "Bahamas",
        "dial_code": 1,
        "country_code": "bs"
    },
    "bh": {
        "country": "Bahrain (‫البحرين‬‎)",
        "dial_code": 973,
        "country_code": "bh"
    },
    "bd": {
        "country": "Bangladesh (বাংলাদেশ)",
        "dial_code": 880,
        "country_code": "bd"
    },
    "bb": {
        "country": "Barbados",
        "dial_code": 1,
        "country_code": "bb"
    },
    "by": {
        "country": "Belarus (Беларусь)",
        "dial_code": 375,
        "country_code": "by"
    },
    "be": {
        "country": "Belgium (België)",
        "dial_code": 32,
        "country_code": "be"
    },
    "bz": {
        "country": "Belize",
        "dial_code": 501,
        "country_code": "bz"
    },
    "bj": {
        "country": "Benin (Bénin)",
        "dial_code": 229,
        "country_code": "bj"
    },
    "bm": {
        "country": "Bermuda",
        "dial_code": 1,
        "country_code": "bm"
    },
    "bt": {
        "country": "Bhutan (འབྲུག)",
        "dial_code": 975,
        "country_code": "bt"
    },
    "bo": {
        "country": "Bolivia",
        "dial_code": 591,
        "country_code": "bo"
    },
    "ba": {
        "country": "Bosnia and Herzegovina (Босна и Херцеговина)",
        "dial_code": 387,
        "country_code": "ba"
    },
    "bw": {
        "country": "Botswana",
        "dial_code": 267,
        "country_code": "bw"
    },
    "br": {
        "country": "Brazil (Brasil)",
        "dial_code": 55,
        "country_code": "br"
    },
    "io": {
        "country": "British Indian Ocean Territory",
        "dial_code": 246,
        "country_code": "io"
    },
    "vg": {
        "country": "British Virgin Islands",
        "dial_code": 1,
        "country_code": "vg"
    },
    "bn": {
        "country": "Brunei",
        "dial_code": 673,
        "country_code": "bn"
    },
    "bg": {
        "country": "Bulgaria (България)",
        "dial_code": 359,
        "country_code": "bg"
    },
    "bf": {
        "country": "Burkina Faso",
        "dial_code": 226,
        "country_code": "bf"
    },
    "bi": {
        "country": "Burundi (Uburundi)",
        "dial_code": 257,
        "country_code": "bi"
    },
    "kh": {
        "country": "Cambodia (កម្ពុជា)",
        "dial_code": 855,
        "country_code": "kh"
    },
    "cm": {
        "country": "Cameroon (Cameroun)",
        "dial_code": 237,
        "country_code": "cm"
    },
    "ca": {
        "country": "Canada",
        "dial_code": 1,
        "country_code": "ca"
    },
    "cv": {
        "country": "Cape Verde (Kabu Verdi)",
        "dial_code": 238,
        "country_code": "cv"
    },
    "bq": {
        "country": "Caribbean Netherlands",
        "dial_code": 599,
        "country_code": "bq"
    },
    "ky": {
        "country": "Cayman Islands",
        "dial_code": 1,
        "country_code": "ky"
    },
    "cf": {
        "country": "Central African Republic (République centrafricaine)",
        "dial_code": 236,
        "country_code": "cf"
    },
    "td": {
        "country": "Chad (Tchad)",
        "dial_code": 235,
        "country_code": "td"
    },
    "cl": {
        "country": "Chile",
        "dial_code": 56,
        "country_code": "cl"
    },
    "cn": {
        "country": "China (中国)",
        "dial_code": 86,
        "country_code": "cn"
    },
    "cx": {
        "country": "Christmas Island",
        "dial_code": 61,
        "country_code": "cx"
    },
    "cc": {
        "country": "Cocos (Keeling) Islands",
        "dial_code": 61,
        "country_code": "cc"
    },
    "co": {
        "country": "Colombia",
        "dial_code": 57,
        "country_code": "co"
    },
    "km": {
        "country": "Comoros (‫جزر القمر‬‎)",
        "dial_code": 269,
        "country_code": "km"
    },
    "cd": {
        "country": "Congo (DRC) (Jamhuri ya Kidemokrasia ya Kongo)",
        "dial_code": 243,
        "country_code": "cd"
    },
    "cg": {
        "country": "Congo (Republic) (Congo-Brazzaville)",
        "dial_code": 242,
        "country_code": "cg"
    },
    "ck": {
        "country": "Cook Islands",
        "dial_code": 682,
        "country_code": "ck"
    },
    "cr": {
        "country": "Costa Rica",
        "dial_code": 506,
        "country_code": "cr"
    },
    "ci": {
        "country": "Côte d’Ivoire",
        "dial_code": 225,
        "country_code": "ci"
    },
    "hr": {
        "country": "Croatia (Hrvatska)",
        "dial_code": 385,
        "country_code": "hr"
    },
    "cu": {
        "country": "Cuba",
        "dial_code": 53,
        "country_code": "cu"
    },
    "cw": {
        "country": "Curaçao",
        "dial_code": 599,
        "country_code": "cw"
    },
    "cy": {
        "country": "Cyprus (Κύπρος)",
        "dial_code": 357,
        "country_code": "cy"
    },
    "cz": {
        "country": "Czech Republic (Česká republika)",
        "dial_code": 420,
        "country_code": "cz"
    },
    "dk": {
        "country": "Denmark (Danmark)",
        "dial_code": 45,
        "country_code": "dk"
    },
    "dj": {
        "country": "Djibouti",
        "dial_code": 253,
        "country_code": "dj"
    },
    "dm": {
        "country": "Dominica",
        "dial_code": 1,
        "country_code": "dm"
    },
    "do": {
        "country": "Dominican Republic (República Dominicana)",
        "dial_code": 1,
        "country_code": "do"
    },
    "ec": {
        "country": "Ecuador",
        "dial_code": 593,
        "country_code": "ec"
    },
    "eg": {
        "country": "Egypt (‫مصر‬‎)",
        "dial_code": 20,
        "country_code": "eg"
    },
    "sv": {
        "country": "El Salvador",
        "dial_code": 503,
        "country_code": "sv"
    },
    "gq": {
        "country": "Equatorial Guinea (Guinea Ecuatorial)",
        "dial_code": 240,
        "country_code": "gq"
    },
    "er": {
        "country": "Eritrea",
        "dial_code": 291,
        "country_code": "er"
    },
    "ee": {
        "country": "Estonia (Eesti)",
        "dial_code": 372,
        "country_code": "ee"
    },
    "et": {
        "country": "Ethiopia",
        "dial_code": 251,
        "country_code": "et"
    },
    "fk": {
        "country": "Falkland Islands (Islas Malvinas)",
        "dial_code": 500,
        "country_code": "fk"
    },
    "fo": {
        "country": "Faroe Islands (Føroyar)",
        "dial_code": 298,
        "country_code": "fo"
    },
    "fj": {
        "country": "Fiji",
        "dial_code": 679,
        "country_code": "fj"
    },
    "fi": {
        "country": "Finland (Suomi)",
        "dial_code": 358,
        "country_code": "fi"
    },
    "fr": {
        "country": "France",
        "dial_code": 33,
        "country_code": "fr"
    },
    "gf": {
        "country": "French Guiana (Guyane française)",
        "dial_code": 594,
        "country_code": "gf"
    },
    "pf": {
        "country": "French Polynesia (Polynésie française)",
        "dial_code": 689,
        "country_code": "pf"
    },
    "ga": {
        "country": "Gabon",
        "dial_code": 241,
        "country_code": "ga"
    },
    "gm": {
        "country": "Gambia",
        "dial_code": 220,
        "country_code": "gm"
    },
    "ge": {
        "country": "Georgia (საქართველო)",
        "dial_code": 995,
        "country_code": "ge"
    },
    "de": {
        "country": "Germany (Deutschland)",
        "dial_code": 49,
        "country_code": "de"
    },
    "gh": {
        "country": "Ghana (Gaana)",
        "dial_code": 233,
        "country_code": "gh"
    },
    "gi": {
        "country": "Gibraltar",
        "dial_code": 350,
        "country_code": "gi"
    },
    "gr": {
        "country": "Greece (Ελλάδα)",
        "dial_code": 30,
        "country_code": "gr"
    },
    "gl": {
        "country": "Greenland (Kalaallit Nunaat)",
        "dial_code": 299,
        "country_code": "gl"
    },
    "gd": {
        "country": "Grenada",
        "dial_code": 1,
        "country_code": "gd"
    },
    "gp": {
        "country": "Guadeloupe",
        "dial_code": 590,
        "country_code": "gp"
    },
    "gu": {
        "country": "Guam",
        "dial_code": 1,
        "country_code": "gu"
    },
    "gt": {
        "country": "Guatemala",
        "dial_code": 502,
        "country_code": "gt"
    },
    "gg": {
        "country": "Guernsey",
        "dial_code": 44,
        "country_code": "gg"
    },
    "gn": {
        "country": "Guinea (Guinée)",
        "dial_code": 224,
        "country_code": "gn"
    },
    "gw": {
        "country": "Guinea-Bissau (Guiné Bissau)",
        "dial_code": 245,
        "country_code": "gw"
    },
    "gy": {
        "country": "Guyana",
        "dial_code": 592,
        "country_code": "gy"
    },
    "ht": {
        "country": "Haiti",
        "dial_code": 509,
        "country_code": "ht"
    },
    "hn": {
        "country": "Honduras",
        "dial_code": 504,
        "country_code": "hn"
    },
    "hk": {
        "country": "Hong Kong (香港)",
        "dial_code": 852,
        "country_code": "hk"
    },
    "hu": {
        "country": "Hungary (Magyarország)",
        "dial_code": 36,
        "country_code": "hu"
    },
    "is": {
        "country": "Iceland (Ísland)",
        "dial_code": 354,
        "country_code": "is"
    },
    "in": {
        "country": "India (भारत)",
        "dial_code": 91,
        "country_code": "in"
    },
    "id": {
        "country": "Indonesia",
        "dial_code": 62,
        "country_code": "id"
    },
    "ir": {
        "country": "Iran (‫ایران‬‎)",
        "dial_code": 98,
        "country_code": "ir"
    },
    "iq": {
        "country": "Iraq (‫العراق‬‎)",
        "dial_code": 964,
        "country_code": "iq"
    },
    "ie": {
        "country": "Ireland",
        "dial_code": 353,
        "country_code": "ie"
    },
    "im": {
        "country": "Isle of Man",
        "dial_code": 44,
        "country_code": "im"
    },
    "il": {
        "country": "Israel (‫ישראל‬‎)",
        "dial_code": 972,
        "country_code": "il"
    },
    "it": {
        "country": "Italy (Italia)",
        "dial_code": 39,
        "country_code": "it"
    },
    "jm": {
        "country": "Jamaica",
        "dial_code": 1,
        "country_code": "jm"
    },
    "jp": {
        "country": "Japan (日本)",
        "dial_code": 81,
        "country_code": "jp"
    },
    "je": {
        "country": "Jersey",
        "dial_code": 44,
        "country_code": "je"
    },
    "jo": {
        "country": "Jordan (‫الأردن‬‎)",
        "dial_code": 962,
        "country_code": "jo"
    },
    "kz": {
        "country": "Kazakhstan (Казахстан)",
        "dial_code": 7,
        "country_code": "kz"
    },
    "ke": {
        "country": "Kenya",
        "dial_code": 254,
        "country_code": "ke"
    },
    "ki": {
        "country": "Kiribati",
        "dial_code": 686,
        "country_code": "ki"
    },
    "xk": {
        "country": "Kosovo",
        "dial_code": 383,
        "country_code": "xk"
    },
    "kw": {
        "country": "Kuwait (‫الكويت‬‎)",
        "dial_code": 965,
        "country_code": "kw"
    },
    "kg": {
        "country": "Kyrgyzstan (Кыргызстан)",
        "dial_code": 996,
        "country_code": "kg"
    },
    "la": {
        "country": "Laos (ລາວ)",
        "dial_code": 856,
        "country_code": "la"
    },
    "lv": {
        "country": "Latvia (Latvija)",
        "dial_code": 371,
        "country_code": "lv"
    },
    "lb": {
        "country": "Lebanon (‫لبنان‬‎)",
        "dial_code": 961,
        "country_code": "lb"
    },
    "ls": {
        "country": "Lesotho",
        "dial_code": 266,
        "country_code": "ls"
    },
    "lr": {
        "country": "Liberia",
        "dial_code": 231,
        "country_code": "lr"
    },
    "ly": {
        "country": "Libya (‫ليبيا‬‎)",
        "dial_code": 218,
        "country_code": "ly"
    },
    "li": {
        "country": "Liechtenstein",
        "dial_code": 423,
        "country_code": "li"
    },
    "lt": {
        "country": "Lithuania (Lietuva)",
        "dial_code": 370,
        "country_code": "lt"
    },
    "lu": {
        "country": "Luxembourg",
        "dial_code": 352,
        "country_code": "lu"
    },
    "mo": {
        "country": "Macau (澳門)",
        "dial_code": 853,
        "country_code": "mo"
    },
    "mk": {
        "country": "Macedonia (FYROM) (Македонија)",
        "dial_code": 389,
        "country_code": "mk"
    },
    "mg": {
        "country": "Madagascar (Madagasikara)",
        "dial_code": 261,
        "country_code": "mg"
    },
    "mw": {
        "country": "Malawi",
        "dial_code": 265,
        "country_code": "mw"
    },
    "my": {
        "country": "Malaysia",
        "dial_code": 60,
        "country_code": "my"
    },
    "mv": {
        "country": "Maldives",
        "dial_code": 960,
        "country_code": "mv"
    },
    "ml": {
        "country": "Mali",
        "dial_code": 223,
        "country_code": "ml"
    },
    "mt": {
        "country": "Malta",
        "dial_code": 356,
        "country_code": "mt"
    },
    "mh": {
        "country": "Marshall Islands",
        "dial_code": 692,
        "country_code": "mh"
    },
    "mq": {
        "country": "Martinique",
        "dial_code": 596,
        "country_code": "mq"
    },
    "mr": {
        "country": "Mauritania (‫موريتانيا‬‎)",
        "dial_code": 222,
        "country_code": "mr"
    },
    "mu": {
        "country": "Mauritius (Moris)",
        "dial_code": 230,
        "country_code": "mu"
    },
    "yt": {
        "country": "Mayotte",
        "dial_code": 262,
        "country_code": "yt"
    },
    "mx": {
        "country": "Mexico (México)",
        "dial_code": 52,
        "country_code": "mx"
    },
    "fm": {
        "country": "Micronesia",
        "dial_code": 691,
        "country_code": "fm"
    },
    "md": {
        "country": "Moldova (Republica Moldova)",
        "dial_code": 373,
        "country_code": "md"
    },
    "mc": {
        "country": "Monaco",
        "dial_code": 377,
        "country_code": "mc"
    },
    "mn": {
        "country": "Mongolia (Монгол)",
        "dial_code": 976,
        "country_code": "mn"
    },
    "me": {
        "country": "Montenegro (Crna Gora)",
        "dial_code": 382,
        "country_code": "me"
    },
    "ms": {
        "country": "Montserrat",
        "dial_code": 1,
        "country_code": "ms"
    },
    "ma": {
        "country": "Morocco (‫المغرب‬‎)",
        "dial_code": 212,
        "country_code": "ma"
    },
    "mz": {
        "country": "Mozambique (Moçambique)",
        "dial_code": 258,
        "country_code": "mz"
    },
    "mm": {
        "country": "Myanmar (Burma) (မြန်မာ)",
        "dial_code": 95,
        "country_code": "mm"
    },
    "na": {
        "country": "Namibia (Namibië)",
        "dial_code": 264,
        "country_code": "na"
    },
    "nr": {
        "country": "Nauru",
        "dial_code": 674,
        "country_code": "nr"
    },
    "np": {
        "country": "Nepal (नेपाल)",
        "dial_code": 977,
        "country_code": "np"
    },
    "nl": {
        "country": "Netherlands (Nederland)",
        "dial_code": 31,
        "country_code": "nl"
    },
    "nc": {
        "country": "New Caledonia (Nouvelle-Calédonie)",
        "dial_code": 687,
        "country_code": "nc"
    },
    "nz": {
        "country": "New Zealand",
        "dial_code": 64,
        "country_code": "nz"
    },
    "ni": {
        "country": "Nicaragua",
        "dial_code": 505,
        "country_code": "ni"
    },
    "ne": {
        "country": "Niger (Nijar)",
        "dial_code": 227,
        "country_code": "ne"
    },
    "ng": {
        "country": "Nigeria",
        "dial_code": 234,
        "country_code": "ng"
    },
    "nu": {
        "country": "Niue",
        "dial_code": 683,
        "country_code": "nu"
    },
    "nf": {
        "country": "Norfolk Island",
        "dial_code": 672,
        "country_code": "nf"
    },
    "kp": {
        "country": "North Korea (조선 민주주의 인민 공화국)",
        "dial_code": 850,
        "country_code": "kp"
    },
    "mp": {
        "country": "Northern Mariana Islands",
        "dial_code": 1,
        "country_code": "mp"
    },
    "no": {
        "country": "Norway (Norge)",
        "dial_code": 47,
        "country_code": "no"
    },
    "om": {
        "country": "Oman (‫عُمان‬‎)",
        "dial_code": 968,
        "country_code": "om"
    },
    "pk": {
        "country": "Pakistan (‫پاکستان‬‎)",
        "dial_code": 92,
        "country_code": "pk"
    },
    "pw": {
        "country": "Palau",
        "dial_code": 680,
        "country_code": "pw"
    },
    "ps": {
        "country": "Palestine (‫فلسطين‬‎)",
        "dial_code": 970,
        "country_code": "ps"
    },
    "pa": {
        "country": "Panama (Panamá)",
        "dial_code": 507,
        "country_code": "pa"
    },
    "pg": {
        "country": "Papua New Guinea",
        "dial_code": 675,
        "country_code": "pg"
    },
    "py": {
        "country": "Paraguay",
        "dial_code": 595,
        "country_code": "py"
    },
    "pe": {
        "country": "Peru (Perú)",
        "dial_code": 51,
        "country_code": "pe"
    },
    "ph": {
        "country": "Philippines",
        "dial_code": 63,
        "country_code": "ph"
    },
    "pl": {
        "country": "Poland (Polska)",
        "dial_code": 48,
        "country_code": "pl"
    },
    "pt": {
        "country": "Portugal",
        "dial_code": 351,
        "country_code": "pt"
    },
    "pr": {
        "country": "Puerto Rico",
        "dial_code": 1,
        "country_code": "pr"
    },
    "qa": {
        "country": "Qatar (‫قطر‬‎)",
        "dial_code": 974,
        "country_code": "qa"
    },
    "re": {
        "country": "Réunion (La Réunion)",
        "dial_code": 262,
        "country_code": "re"
    },
    "ro": {
        "country": "Romania (România)",
        "dial_code": 40,
        "country_code": "ro"
    },
    "ru": {
        "country": "Russia (Россия)",
        "dial_code": 7,
        "country_code": "ru"
    },
    "rw": {
        "country": "Rwanda",
        "dial_code": 250,
        "country_code": "rw"
    },
    "bl": {
        "country": "Saint Barthélemy",
        "dial_code": 590,
        "country_code": "bl"
    },
    "sh": {
        "country": "Saint Helena",
        "dial_code": 290,
        "country_code": "sh"
    },
    "kn": {
        "country": "Saint Kitts and Nevis",
        "dial_code": 1,
        "country_code": "kn"
    },
    "lc": {
        "country": "Saint Lucia",
        "dial_code": 1,
        "country_code": "lc"
    },
    "mf": {
        "country": "Saint Martin (Saint-Martin (partie française))",
        "dial_code": 590,
        "country_code": "mf"
    },
    "pm": {
        "country": "Saint Pierre and Miquelon (Saint-Pierre-et-Miquelon)",
        "dial_code": 508,
        "country_code": "pm"
    },
    "vc": {
        "country": "Saint Vincent and the Grenadines",
        "dial_code": 1,
        "country_code": "vc"
    },
    "ws": {
        "country": "Samoa",
        "dial_code": 685,
        "country_code": "ws"
    },
    "sm": {
        "country": "San Marino",
        "dial_code": 378,
        "country_code": "sm"
    },
    "st": {
        "country": "São Tomé and Príncipe (São Tomé e Príncipe)",
        "dial_code": 239,
        "country_code": "st"
    },
    "sa": {
        "country": "Saudi Arabia (‫المملكة العربية السعودية‬‎)",
        "dial_code": 966,
        "country_code": "sa"
    },
    "sn": {
        "country": "Senegal (Sénégal)",
        "dial_code": 221,
        "country_code": "sn"
    },
    "rs": {
        "country": "Serbia (Србија)",
        "dial_code": 381,
        "country_code": "rs"
    },
    "sc": {
        "country": "Seychelles",
        "dial_code": 248,
        "country_code": "sc"
    },
    "sl": {
        "country": "Sierra Leone",
        "dial_code": 232,
        "country_code": "sl"
    },
    "sg": {
        "country": "Singapore",
        "dial_code": 65,
        "country_code": "sg"
    },
    "sx": {
        "country": "Sint Maarten",
        "dial_code": 1,
        "country_code": "sx"
    },
    "sk": {
        "country": "Slovakia (Slovensko)",
        "dial_code": 421,
        "country_code": "sk"
    },
    "si": {
        "country": "Slovenia (Slovenija)",
        "dial_code": 386,
        "country_code": "si"
    },
    "sb": {
        "country": "Solomon Islands",
        "dial_code": 677,
        "country_code": "sb"
    },
    "so": {
        "country": "Somalia (Soomaaliya)",
        "dial_code": 252,
        "country_code": "so"
    },
    "za": {
        "country": "South Africa",
        "dial_code": 27,
        "country_code": "za"
    },
    "kr": {
        "country": "South Korea (대한민국)",
        "dial_code": 82,
        "country_code": "kr"
    },
    "ss": {
        "country": "South Sudan (‫جنوب السودان‬‎)",
        "dial_code": 211,
        "country_code": "ss"
    },
    "es": {
        "country": "Spain (España)",
        "dial_code": 34,
        "country_code": "es"
    },
    "lk": {
        "country": "Sri Lanka (ශ්‍රී ලංකාව)",
        "dial_code": 94,
        "country_code": "lk"
    },
    "sd": {
        "country": "Sudan (‫السودان‬‎)",
        "dial_code": 249,
        "country_code": "sd"
    },
    "sr": {
        "country": "Suriname",
        "dial_code": 597,
        "country_code": "sr"
    },
    "sj": {
        "country": "Svalbard and Jan Mayen",
        "dial_code": 47,
        "country_code": "sj"
    },
    "sz": {
        "country": "Swaziland",
        "dial_code": 268,
        "country_code": "sz"
    },
    "se": {
        "country": "Sweden (Sverige)",
        "dial_code": 46,
        "country_code": "se"
    },
    "ch": {
        "country": "Switzerland (Schweiz)",
        "dial_code": 41,
        "country_code": "ch"
    },
    "sy": {
        "country": "Syria (‫سوريا‬‎)",
        "dial_code": 963,
        "country_code": "sy"
    },
    "tw": {
        "country": "Taiwan (台灣)",
        "dial_code": 886,
        "country_code": "tw"
    },
    "tj": {
        "country": "Tajikistan",
        "dial_code": 992,
        "country_code": "tj"
    },
    "tz": {
        "country": "Tanzania",
        "dial_code": 255,
        "country_code": "tz"
    },
    "th": {
        "country": "Thailand (ไทย)",
        "dial_code": 66,
        "country_code": "th"
    },
    "tl": {
        "country": "Timor-Leste",
        "dial_code": 670,
        "country_code": "tl"
    },
    "tg": {
        "country": "Togo",
        "dial_code": 228,
        "country_code": "tg"
    },
    "tk": {
        "country": "Tokelau",
        "dial_code": 690,
        "country_code": "tk"
    },
    "to": {
        "country": "Tonga",
        "dial_code": 676,
        "country_code": "to"
    },
    "tt": {
        "country": "Trinidad and Tobago",
        "dial_code": 1,
        "country_code": "tt"
    },
    "tn": {
        "country": "Tunisia (‫تونس‬‎)",
        "dial_code": 216,
        "country_code": "tn"
    },
    "tr": {
        "country": "Turkey (Türkiye)",
        "dial_code": 90,
        "country_code": "tr"
    },
    "tm": {
        "country": "Turkmenistan",
        "dial_code": 993,
        "country_code": "tm"
    },
    "tc": {
        "country": "Turks and Caicos Islands",
        "dial_code": 1,
        "country_code": "tc"
    },
    "tv": {
        "country": "Tuvalu",
        "dial_code": 688,
        "country_code": "tv"
    },
    "vi": {
        "country": "U.S. Virgin Islands",
        "dial_code": 1,
        "country_code": "vi"
    },
    "ug": {
        "country": "Uganda",
        "dial_code": 256,
        "country_code": "ug"
    },
    "ua": {
        "country": "Ukraine (Україна)",
        "dial_code": 380,
        "country_code": "ua"
    },
    "ae": {
        "country": "United Arab Emirates (‫الإمارات العربية المتحدة‬‎)",
        "dial_code": 971,
        "country_code": "ae"
    },
    "uy": {
        "country": "Uruguay",
        "dial_code": 598,
        "country_code": "uy"
    },
    "uz": {
        "country": "Uzbekistan (Oʻzbekiston)",
        "dial_code": 998,
        "country_code": "uz"
    },
    "vu": {
        "country": "Vanuatu",
        "dial_code": 678,
        "country_code": "vu"
    },
    "va": {
        "country": "Vatican City (Città del Vaticano)",
        "dial_code": 39,
        "country_code": "va"
    },
    "ve": {
        "country": "Venezuela",
        "dial_code": 58,
        "country_code": "ve"
    },
    "vn": {
        "country": "Vietnam (Việt Nam)",
        "dial_code": 84,
        "country_code": "vn"
    },
    "wf": {
        "country": "Wallis and Futuna (Wallis-et-Futuna)",
        "dial_code": 681,
        "country_code": "wf"
    },
    "eh": {
        "country": "Western Sahara (‫الصحراء الغربية‬‎)",
        "dial_code": 212,
        "country_code": "eh"
    },
    "ye": {
        "country": "Yemen (‫اليمن‬‎)",
        "dial_code": 967,
        "country_code": "ye"
    },
    "zm": {
        "country": "Zambia",
        "dial_code": 260,
        "country_code": "zm"
    },
    "zw": {
        "country": "Zimbabwe",
        "dial_code": 263,
        "country_code": "zw"
    },
    "ax": {
        "country": "Åland Islands",
        "dial_code": 358,
        "country_code": "ax"
    }
};