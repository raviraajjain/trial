package by.chemerisuk.cordova.support;

public enum ExecutionThread {
    MAIN, UI, WORKER
}
